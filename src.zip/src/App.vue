<!--
 * @Descripttion: 陈品富写的demo描述
 * @version: 1.0
 * @Author: chenpinfu~陈品富
 * @Date: 2020-09-05 17:10:04
 * @LastEditors: chenpinfu~陈品富
 * @LastEditTime: 2020-09-13 09:44:08
-->
<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> |
      <router-link to="/treeCharts">TreeCharts</router-link> |
      <router-link to="/ProcessHtml">ProcessHtml</router-link> |
      <router-link to="/eventsChart">EventsChart</router-link> |
      <router-link to="/treeCollapsed">treeCollapsed</router-link>
    </div>
    <router-view />
  </div>
</template>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
